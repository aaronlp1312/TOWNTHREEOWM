# Rainier changelog

## 2.0.1
- API key loads from the device file /storage/emulated/0/weatherapi (CFG.keyFiles), any layout, it finds the 32 character key. Falls back to a copy next to the page, then the last key it saw. %OWM_KEY% injection still wins if Tasker fills it.
- Status line in the panel: key source, OWM result or error, icon, mm, rain and fog levels, so problems show on screen.
- Rain no longer vanishes when the icon says rain but OWM reports a tiny mm value.

## 2.0.0
- Sky view widened (SKY_Z in config.js): the sky now shows about 0 to 42 degrees above the horizon, so the noon sun and the moon are in frame. Water view is unchanged.
- Stars: bigger, brighter, more of them; a few bright ones.
- Sun and moon disc sizes retuned (sunDeg 3.5, moonDeg 4.0).
- Parallax PNG stack: far group (peak, horizon) sits behind the clouds, near group (shore, bridge, driftwood, cliff) sits in front of water and weather. Layers are listed in CFG.plx and any missing PNG is skipped. Depth k per layer, night lighting follows the sky, flashes with lightning.
- Pan is clamped (CFG.panLimit degrees) so the PNG edges never show.
- Fog and haze layer in the precip canvas (fog icon, plus haze with rain).
- Long-press (0.7s) on the scene toggles the debug panel. CFG.ui.startHidden hides it at launch.
- Version shown in the panel, tab title and file headers.

## 1.4.0
- Precip spectrum (mist to downpour, rain to snow, hail) in one canvas: js/precip.js.
- Lightning: bolt, cloud flash, delayed scene shake: js/lightning.js.
- Stage wrapper (#rainier-stage) so the shake moves every layer.
- Debug: precip and temp sliders, Zap button.

## 1.3.0
- Time travel swipe: +24h forecast and -24h history, inertia, return home, double-tap home.
- js/weather.js and js/timeline.js.

## 1.2.0
- Cloud canvas: cirrus plus volumetric deck, storm darkness inside the clouds.

## 1.1.0
- 24 hourly sky gradients as CSS variables, sunrise and sunset driven.
- Modular split: config, astro, shaders, sky-gradient, river, scene, controls, main.

## 1.0.0
- River water shader on three r185 with Timer, sky, sun, moon, procedural stars and Milky Way.
