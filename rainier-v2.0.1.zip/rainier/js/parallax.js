// rainier v2.0.1
import { CFG, RAD, SKY_Z, state } from './config.js';
import { clouds } from './clouds.js';
import { lightning } from './lightning.js';

const layers = [];
let lastLight = -1;
const root = document.documentElement;

export function resizeParallax() {
  const H = window.innerHeight;
  const W = window.innerWidth;
  const pxRad = H * SKY_Z / 2;
  const lim = CFG.panLimit * RAD;
  layers.forEach(function (l) {
    const pad = lim * pxRad * l.k;
    l.el.style.width = (W * l.w / 100 + 2 * pad) + 'px';
  });
}

export function initParallax() {
  const far = document.getElementById('plx-far');
  const near = document.getElementById('plx-near');
  CFG.plx.forEach(function (c) {
    const el = document.createElement('img');
    el.className = 'plx-layer';
    el.alt = '';
    el.draggable = false;
    el.style.bottom = (c.bottom || 0) + 'vh';
    el.style.setProperty('--k', c.k);
    el.addEventListener('error', function () { el.remove(); });
    el.src = c.src;
    (c.group === 'far' ? far : near).appendChild(el);
    layers.push({ el: el, k: c.k, w: c.w || 100 });
  });
  resizeParallax();
}

export function tickParallax() {
  const H = window.innerHeight;
  root.style.setProperty('--plx-x', ((CFG.viewAz * RAD - state.az) * H * SKY_Z / 2).toFixed(1));
  const h = clouds.uniforms.uHor.value;
  const lum = h.x * 0.3 + h.y * 0.59 + h.z * 0.11;
  let L = Math.min(0.22 + 1.5 * lum, 1.05) * (1 - 0.35 * clouds.cur.storm) + lightning.flash * 0.9;
  L = Math.round(L * 200) / 200;
  if (L !== lastLight) {
    lastLight = L;
    root.style.setProperty('--plx-light', L);
  }
}
