// rainier v2.0.1
export const CFG = {
  lat: 46.85,
  lon: -121.76,
  viewAz: 180,
  version: '2.0.1',
  sunDeg: 3.5,
  moonDeg: 4.0,
  owmKey: '%OWM_KEY%',
  keyFiles: ['file:///storage/emulated/0/weatherapi', 'weatherapi'],
  ratio: { sky: 1, sun: 2, moon: 2, clouds: 0.5, river: 1, precip: 1 },
  precip: { mmFull: 8, hail: true, hailWarmC: 12, fade: 1.2 },
  shake: { max: 7 },
  panLimit: 10,
  ui: { startHidden: false },
  plx: [
    { src: 'assets/rainier-peak.png', group: 'far', k: 1.0, w: 100, bottom: 0 },
    { src: 'assets/horizon-strip.png', group: 'far', k: 1.0, w: 100, bottom: 0 },
    { src: 'assets/forested-shore.png', group: 'near', k: 1.15, w: 100, bottom: 0 },
    { src: 'assets/wood-suspension-bridge.png', group: 'near', k: 1.15, w: 100, bottom: 0 },
    { src: 'assets/driftwood.png', group: 'near', k: 1.3, w: 100, bottom: 0 },
    { src: 'assets/cliff-face.png', group: 'near', k: 1.45, w: 100, bottom: 0 }
  ],
  windK: 0.0004,
  evolve: 0.003,
  cloudDefault: 0.45,
  windDefault: { spd: 4, deg: 250 },
  wxSky: 0.6,
  fadeRate: 1.6,
  scrubK: 0.0012,
  pastStepH: 3,
  swipe: { minPerScreen: 720, maxMin: 1440, friction: 2.6, returnSec: 45 }
};

export const RAD = Math.PI / 180;
export const DAY = 86400000;
export const SKY_Z = 1.1;
export const VFOV = 2 * Math.atan(1 / SKY_Z) / RAD;

export const state = {
  az: CFG.viewAz * RAD,
  minutes: null,
  key: '',
  owm: null,
  coverManual: null,
  windManual: null,
  offsetMin: 0,
  scrub: 0,
  owmPast: {},
  wxVer: 0,
  precipManual: null,
  keySrc: 'none',
  owmStatus: 'wait',
  tempManual: null
};
